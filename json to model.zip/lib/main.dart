import 'package:flutter/material.dart';
import 'package:json_to_dart_model/app.dart';

void main() {
  runApp(const AppStart());
}
